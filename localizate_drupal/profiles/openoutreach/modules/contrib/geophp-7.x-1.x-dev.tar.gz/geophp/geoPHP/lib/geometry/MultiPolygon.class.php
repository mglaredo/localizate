<?php
/**
 * MultiPolygon: A collection of Polygons
 */
class MultiPolygon extends Collection 
{
  protected $geom_type = 'MultiPolygon';
}
